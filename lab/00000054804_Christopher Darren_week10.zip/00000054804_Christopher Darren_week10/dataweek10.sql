use visprogw10

create TABLE tblmhs
(
nim varchar(10) primary key not null,
nama varchar(50)
);

CREATE TABLE MstDosen
(
KdDosen varchar(50) primary key not null,
NaDosen varchar(50) not null,
Alamat varchar(50) not null,
Notelp varchar(50) not null,
NoHp varchar(20) not null
);


SELECT * FROM tblmhs
SELECT * FROM MstDosen

drop table MstDosen