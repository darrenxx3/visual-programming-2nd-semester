use visprogw10

create TABLE tblmhs
(
nim varchar(10) primary key not null,
nama varchar(50)
);

CREATE TABLE MstDosen
(
KdDosen varchar(50) primary key not null,
NaDosen varchar(50) not null,
Alamat varchar(50) not null,
Notelp varchar(50) not null,
NoHp varchar(20) not null
);


--week11 LAB--
CREATE TABLE MstPelanggan
(
KodePelanggan varchar(4) primary key not null,
Nama varchar(50) not null,
Alamat varchar(50) not null,
Umur varchar(50) not null
);


SELECT * FROM tblmhs
SELECT * FROM MstDosen
--week11lab--
SELECT * FROM MstPelanggan

drop table MstDosen
drop table tblmhs