﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance_form
{
    class turunan : induk
    {
        public double Jamkerja;

        public double JAMKERJA
        { get; set; }

        public double UpahJamKerja;
        public double UPAHJAMKERJA
        { get; set;}


        public double UpahPerjam;
        public double UPAHPERJAM
        { get; set; }
      }
 } 
