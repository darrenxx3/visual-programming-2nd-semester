﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance_form
{
    class induk
    {
        public double UpahTambahan;
        public double UPAHtambahan
        { get; set; }// buat taro jumlah duit yang ingin dimasukkan


}
}