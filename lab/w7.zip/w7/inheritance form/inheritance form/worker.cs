﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance_form
{
    class worker
    {
        public String Nama;
        public String NAMA
        { get; set; }

        public String Alamat;
        public String ALAMAT
        { get; set; }

        public String Tgl_Lahir;
        public String TGLLAHIR
        { get; set; }


    }
}
