﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2_CHRISTOPHER_DARREN
{
    public partial class FormAnak1 : Form
    {
        public FormAnak1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

            if(e.KeyCode == Keys.Enter)//apabila tombol Enter ditekan akan muncul
            {
                listBox1.Items.Add(textBox1.Text);//akan ditampilkan ke listbox dari textbox
                //comboBox1.Items.Add(textBox1.Text);//akan ditampilkan ke comboxbox(di klik dulu segitiga kecilnya) dari textbox

            }
            if(e.KeyCode == Keys.Escape)//apabila tombol escape ditekan akan muncul
            {
                comboBox1.Items.Add(textBox1.Text);
                
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double avg = 0, sum = 0;
            int LISTCOUNT = listBox1.Items.Count;//dihitung dulu totalnya berapa
            for(int x = 0; x < LISTCOUNT; x++)
            {
                sum += Convert.ToDouble(listBox1.Items[x]);
            }
            avg = sum / LISTCOUNT;
            textBox2.Text = Convert.ToString(avg);
        }

        private void button5_Click(object sender, EventArgs e)// ini adalah alternatif menggunakan button tapi utk sekarang saya komen dahulu
        {
           // if(comboBox1.SelectedIndex > -1)
            {
               // object item1 = comboBox1.SelectedItem;
               // listBox1.Items.Add(item1);
            }
        }
        
        private void button3_Click(object sender, EventArgs e)// mindahin data list ke checkboxtlist di tab2
        {
            foreach(object ggeming in listBox1.SelectedItems)
            {
                checkedListBox1.Items.Add(ggeming.ToString());
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Add(comboBox1.SelectedItem);//data di combox ketika diklik akan ditampilin ke listbox
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double avg = 0, sum = 0;
            int COMBOBOX = comboBox1.Items.Count;//dihitung dulu totalnya berapa
            for (int y = 0; y < COMBOBOX; y++)
            {
                sum += Convert.ToDouble(comboBox1.Items[y]);
            }
            avg = sum / COMBOBOX;
            textBox2.Text = Convert.ToString(avg);
        }
    }
}
