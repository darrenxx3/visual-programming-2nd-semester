﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2_CHRISTOPHER_DARREN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void createFormChildToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAnak1 showform = new FormAnak1();
            showform.Show();
        }

        private void formControlStructureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAnak2 showform = new FormAnak2();
            showform.Show();
        }

        private void titleHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //LayoutMdi(MdiLayout.TileHorizontal);
            FormAnak1 form = new FormAnak1();//manggil mdichildform yaitu si formAnak1
            form.MdiParent = Form1.ActiveForm;
            //form.Mdiparent = form1.activeform adalah tampilan form saat ini(form1)
            form.Show();
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void titleVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //LayoutMdi(MdiLayout.TileVertical);
            FormAnak1 form = new FormAnak1();//manggil mdichildform
            form.MdiParent = Form1.ActiveForm;
            //form.Mdiparent = form1.activeform adalah tampilan form saat ini(form1)
            form.Show();
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAnak1 form = new FormAnak1();//manggil mdichildform
            form.MdiParent = Form1.ActiveForm;
            //form.Mdiparent = form1.activeform adalah tampilan form saat ini(form1)
            form.Show();
            this.LayoutMdi(MdiLayout.Cascade);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
