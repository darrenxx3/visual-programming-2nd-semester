﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace WindowsFormsApp1_CHRISTOPHER_DARREN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                label3.Text = textBox1.Text;//ketika dienter akan menampilkan ke label3
            }
        }

        private void labelResultClearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label3.Text = "";
        }

        private void disabledToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;//mengabu abukan textbox
        }

        private void enablesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;//menampilkan texboxtaktif
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label3.ForeColor = Color.Blue;//mengubahwarna
        }

        private void yellowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label3.ForeColor = Color.Yellow;
        }

        private void boldToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 label = new Form1();
            label3.Font = new Font(label3.Font, FontStyle.Bold);//ubahfont style
        }

        private void italicsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 label = new Form1();
            label3.Font = new Font(label3.Font, FontStyle.Italic);//ubahfont style

        }

        private void underlineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 label = new Form1();
            label3.Font = new Font(label3.Font, FontStyle.Underline);//ubahfont style
        }
    }
}
