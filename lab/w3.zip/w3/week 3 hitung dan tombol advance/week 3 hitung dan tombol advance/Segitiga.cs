﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_3_hitung_dan_tombol_advance
{
    class Segitiga
    {
        public Double week_3_hitung_dan_tombol_advance(Double angka1, Double angka2)
        {
            return angka1 * angka2 / 2;
        }
    }
}
