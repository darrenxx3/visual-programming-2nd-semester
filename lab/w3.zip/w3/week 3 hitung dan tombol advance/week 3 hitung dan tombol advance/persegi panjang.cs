﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_3_hitung_dan_tombol_advance
{
    class persegi_panjang
    {

        public int week_3_hitung_dan_tombol_advance(int angka1, int angka2)
        {
            return angka1 * angka2;
        }
        
    }
}
